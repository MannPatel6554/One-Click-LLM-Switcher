// ============================================================
// One-Click LLM Switcher — background.js (Service Worker)
// Job: popup ka message sunna, current tab se chat scrape
//      karna, aur target AI site khol kar data inject karna
// ============================================================

const TARGET_URLS = {
  chatgpt: 'https://chatgpt.com/',
  gemini:  'https://gemini.google.com/',
  grok:    'https://grok.com/',
  claude:  'https://claude.ai/new',
};

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'SWITCH_TO') {
    const target = msg.target; // 'chatgpt' | 'gemini' | 'grok' | 'claude'

    // 1. Active tab lo
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      const activeTab = tabs[0];
      if (!activeTab?.id) return;

      try {
        // 2. Current page se chat scrape karo
        const response = await chrome.tabs.sendMessage(activeTab.id, { action: 'SCRAPE_CHAT' });
        const chat = response?.chat || '';

        if (!chat || chat.includes('[Koi chat nahi mili')) {
          // Chat nahi mili — sirf new tab kholo
          chrome.tabs.create({ url: TARGET_URLS[target] });
          sendResponse({ success: false, reason: 'no_chat' });
          return;
        }

        // 3. Chat ko storage mein save karo
        await chrome.storage.local.set({
          pendingChat: chat,
          pendingTarget: target,
          savedAt: Date.now(),
        });

        // 4. Target AI ka tab kholo — content.js wahan inject karega
        chrome.tabs.create({ url: TARGET_URLS[target] });
        sendResponse({ success: true, charCount: chat.length });

      } catch (err) {
        // Content script nahi mili (e.g., non-AI page pe hain)
        // Sirf tab kholo
        chrome.tabs.create({ url: TARGET_URLS[target] });
        sendResponse({ success: false, reason: 'content_script_error', error: err.message });
      }
    });

    return true; // async response ke liye zaroori
  }
});

// ─── CLEANUP — 1 ghante baad stale data hata do ─────────────
chrome.storage.local.get(['savedAt'], (result) => {
  if (result.savedAt && Date.now() - result.savedAt > 3600000) {
    chrome.storage.local.remove(['pendingChat', 'pendingTarget', 'savedAt']);
  }
});
