// ============================================================
// One-Click LLM Switcher — content.js
// Runs on: Claude, ChatGPT, Gemini, Grok
// Job: Scrape current chat OR inject incoming chat
// ============================================================

const HOSTNAME = window.location.hostname;

// ─── SCRAPER FUNCTIONS ───────────────────────────────────────

function scrapeClaudeChat() {
  const messages = [];
  // Claude uses data-is-streaming and font-claude-message classes
  const humanMsgs = document.querySelectorAll('[data-testid="human-turn-content"], .font-user-message');
  const aiMsgs = document.querySelectorAll('[data-testid="ai-turn-content"], .font-claude-message');

  // Interleave by DOM order
  const allTurns = document.querySelectorAll(
    '[data-testid="human-turn"], [data-testid="ai-turn"]'
  );

  if (allTurns.length > 0) {
    allTurns.forEach(turn => {
      const isHuman = turn.getAttribute('data-testid') === 'human-turn';
      const role = isHuman ? 'User' : 'Claude';
      const text = turn.innerText?.trim();
      if (text) messages.push(`${role}: ${text}`);
    });
  } else {
    // Fallback: grab all visible text blocks
    const blocks = document.querySelectorAll('.font-claude-message, .font-user-message');
    blocks.forEach((el, i) => {
      const role = i % 2 === 0 ? 'User' : 'Claude';
      if (el.innerText?.trim()) messages.push(`${role}: ${el.innerText.trim()}`);
    });
  }

  return messages.join('\n\n---\n\n');
}

function scrapeChatGPTChat() {
  const messages = [];
  const turns = document.querySelectorAll('[data-message-author-role]');

  turns.forEach(turn => {
    const role = turn.getAttribute('data-message-author-role');
    const label = role === 'user' ? 'User' : 'ChatGPT';
    const text = turn.innerText?.trim();
    if (text) messages.push(`${label}: ${text}`);
  });

  return messages.join('\n\n---\n\n');
}

function scrapeGeminiChat() {
  const messages = [];
  // Gemini uses model-response and user-query classes
  const queryEls = document.querySelectorAll('.query-text, .user-query-text');
  const responseEls = document.querySelectorAll('.model-response-text, .markdown');

  // Try structured approach
  const userTurns = document.querySelectorAll('user-query');
  const modelTurns = document.querySelectorAll('model-response');

  if (userTurns.length > 0) {
    const maxLen = Math.max(userTurns.length, modelTurns.length);
    for (let i = 0; i < maxLen; i++) {
      if (userTurns[i]) messages.push(`User: ${userTurns[i].innerText?.trim()}`);
      if (modelTurns[i]) messages.push(`Gemini: ${modelTurns[i].innerText?.trim()}`);
    }
  } else {
    // Fallback
    queryEls.forEach(el => { if (el.innerText?.trim()) messages.push(`User: ${el.innerText.trim()}`); });
    responseEls.forEach(el => { if (el.innerText?.trim()) messages.push(`Gemini: ${el.innerText.trim()}`); });
  }

  return messages.join('\n\n---\n\n');
}

function scrapeGrokChat() {
  const messages = [];
  const turns = document.querySelectorAll('[class*="message-bubble"], [class*="conversation-turn"]');

  turns.forEach((el, i) => {
    const role = i % 2 === 0 ? 'User' : 'Grok';
    if (el.innerText?.trim()) messages.push(`${role}: ${el.innerText.trim()}`);
  });

  // Fallback to generic message containers
  if (messages.length === 0) {
    const generic = document.querySelectorAll('[data-testid*="message"], [class*="Message"]');
    generic.forEach((el, i) => {
      const role = i % 2 === 0 ? 'User' : 'Grok';
      if (el.innerText?.trim()) messages.push(`${role}: ${el.innerText.trim()}`);
    });
  }

  return messages.join('\n\n---\n\n');
}

// ─── INJECTOR FUNCTIONS ──────────────────────────────────────

function injectToChatGPT(text) {
  const tryInject = (retries = 10) => {
    const box = document.querySelector('#prompt-textarea, [data-id="root"] textarea, textarea[placeholder*="message"]');
    if (box) {
      // React-friendly value injection
      const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
      nativeInputValueSetter.call(box, text);
      box.dispatchEvent(new Event('input', { bubbles: true }));
      box.focus();
      chrome.storage.local.remove('pendingChat');
      chrome.storage.local.remove('pendingTarget');
    } else if (retries > 0) {
      setTimeout(() => tryInject(retries - 1), 600);
    }
  };
  tryInject();
}

function injectToGemini(text) {
  const tryInject = (retries = 10) => {
    const box = document.querySelector('rich-textarea .ql-editor, [contenteditable="true"][data-placeholder]');
    if (box) {
      box.focus();
      box.innerHTML = '';
      document.execCommand('insertText', false, text);
      chrome.storage.local.remove('pendingChat');
      chrome.storage.local.remove('pendingTarget');
    } else if (retries > 0) {
      setTimeout(() => tryInject(retries - 1), 600);
    }
  };
  tryInject();
}

function injectToGrok(text) {
  const tryInject = (retries = 10) => {
    const box = document.querySelector('textarea[placeholder*="Ask"], textarea[data-testid]');
    if (box) {
      const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
      nativeInputValueSetter.call(box, text);
      box.dispatchEvent(new Event('input', { bubbles: true }));
      box.focus();
      chrome.storage.local.remove('pendingChat');
      chrome.storage.local.remove('pendingTarget');
    } else if (retries > 0) {
      setTimeout(() => tryInject(retries - 1), 600);
    }
  };
  tryInject();
}

function injectToClaude(text) {
  const tryInject = (retries = 10) => {
    const box = document.querySelector('[contenteditable="true"][data-placeholder], .ProseMirror');
    if (box) {
      box.focus();
      box.innerHTML = '';
      document.execCommand('insertText', false, text);
      chrome.storage.local.remove('pendingChat');
      chrome.storage.local.remove('pendingTarget');
    } else if (retries > 0) {
      setTimeout(() => tryInject(retries - 1), 600);
    }
  };
  tryInject();
}

// ─── LISTENER — background.js se message sunna ───────────────

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'SCRAPE_CHAT') {
    let chat = '';
    if (HOSTNAME.includes('claude.ai'))      chat = scrapeClaudeChat();
    if (HOSTNAME.includes('chatgpt.com'))    chat = scrapeChatGPTChat();
    if (HOSTNAME.includes('gemini.google'))  chat = scrapeGeminiChat();
    if (HOSTNAME.includes('grok.com'))       chat = scrapeGrokChat();

    sendResponse({ chat: chat || '[Koi chat nahi mili. Koi AI chat open karein.]' });
    return true;
  }
});

// ─── PAGE LOAD PE CHECK — kya inject karna hai? ──────────────

chrome.storage.local.get(['pendingChat', 'pendingTarget'], (result) => {
  if (!result.pendingChat) return;

  const target = result.pendingTarget;
  if (target === 'chatgpt' && HOSTNAME.includes('chatgpt.com')) injectToChatGPT(result.pendingChat);
  if (target === 'gemini'  && HOSTNAME.includes('gemini.google')) injectToGemini(result.pendingChat);
  if (target === 'grok'    && HOSTNAME.includes('grok.com'))    injectToGrok(result.pendingChat);
  if (target === 'claude'  && HOSTNAME.includes('claude.ai'))   injectToClaude(result.pendingChat);
});
