// ============================================================
// One-Click LLM Switcher — popup.js
// Job: Buttons ko click handle karna, background.js ko message
//      bhejna, aur status UI update karna
// ============================================================

const SUPPORTED_SITES = {
  'claude.ai':        'Claude',
  'chatgpt.com':      'ChatGPT',
  'gemini.google.com':'Gemini',
  'grok.com':         'Grok',
};

// ─── STATUS UI HELPERS ───────────────────────────────────────

function setStatus(text, type = 'idle') {
  const dot  = document.getElementById('statusDot');
  const span = document.getElementById('statusText');
  span.textContent = text;
  dot.className = 'status-dot' + (type === 'active' ? ' active' : type === 'error' ? ' error' : '');
}

function setButtonLoading(btn, isLoading) {
  btn.classList.toggle('loading', isLoading);
  btn.disabled = isLoading;
}

// ─── PAGE DETECTION ──────────────────────────────────────────

chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  const url = tabs[0]?.url || '';
  let siteName = null;

  for (const [domain, name] of Object.entries(SUPPORTED_SITES)) {
    if (url.includes(domain)) { siteName = name; break; }
  }

  if (siteName) {
    setStatus(`${siteName} detect hua — chat copy hogi`, 'active');
  } else {
    setStatus('AI chat page pe jaao phir switch karo', 'error');
    // Disable all buttons if not on a supported site
    document.querySelectorAll('.btn').forEach(btn => { btn.disabled = true; });
  }
});

// ─── BUTTON HANDLERS ─────────────────────────────────────────

function handleSwitch(target, btnId) {
  const btn = document.getElementById(btnId);
  setButtonLoading(btn, true);
  setStatus('Chat copy ho rahi hai…', 'active');

  chrome.runtime.sendMessage({ action: 'SWITCH_TO', target }, (response) => {
    if (chrome.runtime.lastError) {
      setStatus('Error aaya — page reload karein', 'error');
      setButtonLoading(btn, false);
      return;
    }

    if (response?.success) {
      const chars = response.charCount || 0;
      setStatus(`✓ ${chars} chars copy kiye! Tab khul raha hai…`, 'active');
    } else if (response?.reason === 'no_chat') {
      setStatus('Koi chat nahi mili — kuch message karo pehle', 'error');
      setButtonLoading(btn, false);
    } else {
      setStatus('Directly new tab mein ja raha hai', 'idle');
    }

    setTimeout(() => window.close(), 1200);
  });
}

document.getElementById('toChatGPT').addEventListener('click', () => handleSwitch('chatgpt', 'toChatGPT'));
document.getElementById('toGemini').addEventListener('click',  () => handleSwitch('gemini',  'toGemini'));
document.getElementById('toGrok').addEventListener('click',    () => handleSwitch('grok',    'toGrok'));
document.getElementById('toClaude').addEventListener('click',  () => handleSwitch('claude',  'toClaude'));
